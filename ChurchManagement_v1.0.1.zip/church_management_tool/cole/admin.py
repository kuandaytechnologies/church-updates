

from django.contrib import admin
from .models import AnnualTithe
from .models import DailyTithe
from .models import Feasts


@admin.register(AnnualTithe)
class AnnualTitheAdmin(admin.ModelAdmin):
    list_display = ("name", "church_center", "scc", "date", "amount", "telephone")
    search_fields = ("name", "church_center", "scc", "telephone")
    list_filter = ("church_center", "scc", "date")
    ordering = ("-date", "name")

@admin.register(DailyTithe)
class DailyTitheAdmin(admin.ModelAdmin):
    list_display = ("name", "church_center", "scc", "date", "amount", "telephone")
    search_fields = ("name", "church_center", "scc", "telephone")
    list_filter = ("church_center", "scc", "date")
    ordering = ("-date", "name")



@admin.register(Feasts)
class FeastsAdmin(admin.ModelAdmin):
    list_display = ("name", "collection_type", "church_center", "scc", "date", "amount", "telephone")
    search_fields = ("name", "collection_type", "church_center", "scc", "telephone")
    list_filter = ("collection_type", "church_center", "scc", "date")
    ordering = ("-date", "name")




