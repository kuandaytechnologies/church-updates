from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import AnnualTithe, DailyTithe, Feasts
from members.models import ChurchYear
from .models import Feasts, Church, ChurchYear, SCC

from django.http import JsonResponse


#update imports

from django.contrib.admin.views.decorators import staff_member_required
import subprocess
import urllib.request
import json
import os

# ============= DAILY TITHE VIEWS =============
@login_required
def add_daily_tithe_view(request):
    """Add daily tithe"""
    if request.method == 'POST':
        date = request.POST.get('date')
        name = request.POST.get('name')
        church_center_id = request.POST.get('church_center')
        scc_id = request.POST.get('scc')
        amount = request.POST.get('amount')
        telephone = request.POST.get('telephone')
        
        try:
            DailyTithe.objects.create(
                date=date,
                name=name,
                church_center_id=church_center_id,
                scc_id=scc_id if scc_id else None,
                amount=amount,
                telephone=telephone
            )
            messages.success(request, 'Daily tithe added successfully!')
            return redirect('add_daily_tithe')
        except Exception as e:
            messages.error(request, f'Error adding daily tithe: {str(e)}')
    
    churches = Church.objects.filter(is_active=True)
    
    return render(request, 'cole/add_daily_tithe.html', {
        'page_title': 'Add Daily Tithe',
        'churches': churches
    })


@login_required
def view_daily_tithe_view(request):
    """View daily tithes"""
    active_year = ChurchYear.objects.filter(is_active=True).first()
    
    if active_year:
        tithes = DailyTithe.objects.filter(active_year=active_year).select_related('church_center', 'scc')
    else:
        tithes = DailyTithe.objects.all().select_related('church_center', 'scc')
    
    # Filter by church if provided
    church_filter = request.GET.get('church')
    if church_filter:
        tithes = tithes.filter(church_center_id=church_filter)
    
    # Calculate total
    total_amount = sum(tithe.amount for tithe in tithes)
    
    churches = Church.objects.filter(is_active=True)
    
    return render(request, 'cole/view_daily_tithe.html', {
        'page_title': 'View Daily Tithes',
        'tithes': tithes,
        'total_amount': total_amount,
        'churches': churches,
        'selected_church': church_filter
    })


# ============= ANNUAL TITHE VIEWS =============
@login_required
def add_annual_tithe_view(request):
    """Add annual tithe"""
    if request.method == 'POST':
        date = request.POST.get('date')
        name = request.POST.get('name')
        church_center_id = request.POST.get('church_center')
        scc_id = request.POST.get('scc')
        amount = request.POST.get('amount')
        telephone = request.POST.get('telephone')
        
        try:
            AnnualTithe.objects.create(
                date=date,
                name=name,
                church_center_id=church_center_id,
                scc_id=scc_id if scc_id else None,
                amount=amount,
                telephone=telephone
            )
            messages.success(request, 'Annual tithe added successfully!')
            return redirect('add_annual_tithe')
        except Exception as e:
            messages.error(request, f'Error adding annual tithe: {str(e)}')
    
    churches = Church.objects.filter(is_active=True)
    
    return render(request, 'cole/add_annual_tithe.html', {
        'page_title': 'Add Annual Tithe',
        'churches': churches
    })


@login_required
def view_annual_tithe_view(request):
    """View annual tithes"""
    active_year = ChurchYear.objects.filter(is_active=True).first()
    
    if active_year:
        tithes = AnnualTithe.objects.filter(active_year=active_year).select_related('church_center', 'scc')
    else:
        tithes = AnnualTithe.objects.all().select_related('church_center', 'scc')
    
    # Filter by church if provided
    church_filter = request.GET.get('church')
    if church_filter:
        tithes = tithes.filter(church_center_id=church_filter)
    
    # Calculate total
    total_amount = sum(tithe.amount for tithe in tithes)
    
    churches = Church.objects.filter(is_active=True)
    
    return render(request, 'cole/view_annual_tithe.html', {
        'page_title': 'View Annual Tithes',
        'tithes': tithes,
        'total_amount': total_amount,
        'churches': churches,
        'selected_church': church_filter
    })



# ============= FEAST COLLECTION VIEWS =============
@login_required
def add_christmas_view(request):
    """Add Christmas collection"""
    churches = Church.objects.filter(is_active=True)
    return add_feast_collection(request, 'christmas', 'Christmas', churches)


@login_required
def add_easter_view(request):
    """Add Easter collection"""
    churches = Church.objects.filter(is_active=True)
    return add_feast_collection(request, 'easter', 'Easter', churches)


@login_required
def add_mother_mary_view(request):
    """Add Mother Mary collection"""
    churches = Church.objects.filter(is_active=True)
    return add_feast_collection(request, 'mother_mary', 'Mother Mary', churches)


def add_feast_collection(request, collection_type, collection_name, churches):
    """Generic function to add feast collections"""
    if request.method == 'POST':
        date = request.POST.get('date')
        name = request.POST.get('name')
        church_center_id = request.POST.get('church_center')
        scc_id = request.POST.get('scc')
        amount = request.POST.get('amount')
        telephone = request.POST.get('telephone')
        
        try:
            feast = Feasts.objects.create(
                date=date,
                name=name,
                collection_type=collection_type,
                church_center_id=church_center_id,
                scc_id=scc_id if scc_id else None,
                amount=amount,
                telephone=telephone
            )
            messages.success(request, f'{collection_name} collection added successfully!')
            return redirect(request.path)
        except Exception as e:
            messages.error(request, f'Error adding {collection_name} collection: {str(e)}')
    
    return render(request, 'cole/add_feast.html', {
        'page_title': f'Add {collection_name} Collection',
        'collection_name': collection_name,
        'collection_type': collection_type,
        'churches': churches
    })

@login_required
def view_feasts_view(request):
    """View all feast collections"""
    active_year = ChurchYear.objects.filter(is_active=True).first()
    
    if active_year:
        feasts = Feasts.objects.filter(active_year=active_year)
    else:
        feasts = Feasts.objects.all()
    
    # Filter by collection type if provided
    type_filter = request.GET.get('type')
    if type_filter:
        feasts = feasts.filter(collection_type=type_filter)
    
    # Filter by church if provided
    church_filter = request.GET.get('church')
    if church_filter:
        feasts = feasts.filter(church_center=church_filter)
    
    # Calculate totals by type
    totals = {}
    for choice_value, choice_label in Feasts.COLLECTION_TYPE_CHOICES:
        total = sum(f.amount for f in feasts.filter(collection_type=choice_value))
        totals[choice_label] = total
    
    grand_total = sum(totals.values())
    
    # Get dynamic church choices
    church_choices = [(church.code, church.name) for church in Church.objects.filter(is_active=True)]
    
    return render(request, 'cole/view_feasts.html', {
        'page_title': 'View Feast Collections',
        'feasts': feasts,
        'totals': totals,
        'grand_total': grand_total,
        'collection_choices': Feasts.COLLECTION_TYPE_CHOICES,
        'church_choices': church_choices,
        'selected_type': type_filter,
        'selected_church': church_filter
    })

from django.http import JsonResponse

@login_required
def get_sccs_by_church(request):
    """API endpoint to get SCCs for a specific church"""
    church_id = request.GET.get('church_id')
    
    if not church_id:
        return JsonResponse({'sccs': []})
    
    try:
        sccs = SCC.objects.filter(church_id=church_id, is_active=True).values('id', 'name')
        return JsonResponse({'sccs': list(sccs)})
    except Exception as e:
        return JsonResponse({'sccs': [], 'error': str(e)})



# ============= CHURCH CENTER VIEWS =============
@login_required
def town_church_view(request):
    """Town Church collections"""
    return church_center_view(request, 'townChurch', 'Town Church')


@login_required
def nyabukara_church_view(request):
    """Nyabukara Church collections"""
    return church_center_view(request, 'nyabukaraChurch', 'Nyabukara Church')


@login_required
def kagote_church_view(request):
    """Kagote Church collections"""
    return church_center_view(request, 'kagoteChurch', 'Kagote Church')


@login_required
def kyakaigo_church_view(request):
    """Kyakaigo Church collections"""
    return church_center_view(request, 'kyakaigoChurch', 'Kyakaigo Church')


@login_required
def buzinda_church_view(request):
    """Buzinda Church collections"""
    return church_center_view(request, 'buzindaChurch', 'Buzinda Church')


def church_center_view(request, church_code, church_name):
    """Generic function to display church center collections"""
    active_year = ChurchYear.objects.filter(is_active=True).first()
    
    # Get all collections for this church
    if active_year:
        daily_tithes = DailyTithe.objects.filter(
            church_center=church_code,
            active_year=active_year
        )
        annual_tithes = AnnualTithe.objects.filter(
            church_center=church_code,
            active_year=active_year
        )
        feasts = Feasts.objects.filter(
            church_center=church_code,
            active_year=active_year
        )
    else:
        daily_tithes = DailyTithe.objects.filter(church_center=church_code)
        annual_tithes = AnnualTithe.objects.filter(church_center=church_code)
        feasts = Feasts.objects.filter(church_center=church_code)
    
    # Calculate totals
    daily_total = sum(t.amount for t in daily_tithes)
    annual_total = sum(t.amount for t in annual_tithes)
    feasts_total = sum(f.amount for f in feasts)
    grand_total = daily_total + annual_total + feasts_total
    
    return render(request, 'cole/church_center.html', {
        'page_title': church_name,
        'church_name': church_name,
        'church_code': church_code,
        'daily_tithes': daily_tithes,
        'annual_tithes': annual_tithes,
        'feasts': feasts,
        'daily_total': daily_total,
        'annual_total': annual_total,
        'feasts_total': feasts_total,
        'grand_total': grand_total,
    })



#Auto update system
# ADD THESE TWO FUNCTIONS AT THE END OF cole/views.py

@staff_member_required
def update_page_view(request):
    """Update page"""
    from django.conf import settings
    
    try:
        version_file = os.path.join(settings.BASE_DIR, 'version.txt')
        with open(version_file, 'r') as f:
            current_version = f.read().strip()
    except Exception as e:
        current_version = "1.0.0"  # Default if file doesn't exist
    
    return render(request, 'updates/update_page.html', {
        'page_title': 'System Updates',
        'current_version': current_version
    })


@staff_member_required
def check_updates_view(request):
    """Check for updates"""
    import urllib.request
    import json
    from django.conf import settings
    
    try:
        # Read current version
        version_file = os.path.join(settings.BASE_DIR, 'version.txt')
        with open(version_file, 'r') as f:
            current = f.read().strip()
        
        # GitHub raw URL for version.json
        UPDATE_URL = "https://raw.githubusercontent.com/kuandaytechnologies/church-updates/main/version.json"
        
        try:
            # Try to fetch update info from GitHub
            req = urllib.request.Request(UPDATE_URL)
            req.add_header('User-Agent', 'ChurchManagement/1.0')
            response = urllib.request.urlopen(req, timeout=10)
            data = json.loads(response.read().decode('utf-8'))
            
            # Compare versions
            latest_version = data['version']
            update_available = latest_version > current
            
            return JsonResponse({
                'success': True,
                'current_version': current,
                'latest_version': latest_version,
                'update_available': update_available,
                'download_url': data.get('download_url', ''),
                'changes': data.get('changes', 'Bug fixes and improvements'),
                'release_date': data.get('release_date', '')
            })
            
        except urllib.error.URLError:
            # If can't reach GitHub (no internet), show offline mode
            return JsonResponse({
                'success': True,
                'current_version': current,
                'latest_version': current,
                'update_available': False,
                'message': 'Offline mode - Cannot check for updates',
                'download_url': '',
                'changes': '',
                'release_date': ''
            })
    
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e),
            'message': f'Error reading version: {str(e)}'
        })