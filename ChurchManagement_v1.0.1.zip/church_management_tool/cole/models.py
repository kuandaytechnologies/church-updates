# models.py for collections app
from django.db import models
from members.models import ChurchYear, Church, SCC


class AnnualTithe(models.Model):
    date = models.DateField()
    name = models.CharField(max_length=200)
    church_center = models.ForeignKey(
        Church,
        on_delete=models.PROTECT,
        related_name='annual_tithes',
        verbose_name="Church Center"
    )
    scc = models.ForeignKey(
        SCC,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='annual_tithes',
        verbose_name="Small Christian Community"
    )
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    telephone = models.CharField(max_length=20)

    active_year = models.ForeignKey(
        ChurchYear,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='annual_tithes'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Annual Tithe"
        verbose_name_plural = "Annual Tithes"
        ordering = ["-date", "name"]

    def save(self, *args, **kwargs):
        if not self.active_year:
            self.active_year = ChurchYear.objects.filter(is_active=True).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} - {self.church_center.name} ({self.amount})"


class DailyTithe(models.Model):
    date = models.DateField()
    name = models.CharField(max_length=200)
    church_center = models.ForeignKey(
        Church,
        on_delete=models.PROTECT,
        related_name='daily_tithes',
        verbose_name="Church Center"
    )
    scc = models.ForeignKey(
        SCC,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='daily_tithes',
        verbose_name="Small Christian Community"
    )
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    telephone = models.CharField(max_length=20)

    active_year = models.ForeignKey(
        ChurchYear,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='daily_tithes'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Daily Tithe"
        verbose_name_plural = "Daily Tithes"
        ordering = ["-date", "name"]

    def save(self, *args, **kwargs):
        if not self.active_year:
            self.active_year = ChurchYear.objects.filter(is_active=True).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} - {self.church_center.name} ({self.amount})"
    

class Feasts(models.Model):
    COLLECTION_TYPE_CHOICES = [
        ("christmas", "Christmas"),  # Fixed spelling
        ("easter", "Easter"),
        ("mother_mary", "Mother Mary"),
        ("offertory", "Offertory"),
    ]

    date = models.DateField()
    name = models.CharField(max_length=200)
    collection_type = models.CharField(max_length=50, choices=COLLECTION_TYPE_CHOICES)
    church_center = models.ForeignKey(
        Church,
        on_delete=models.PROTECT,
        related_name='feast_collections',
        verbose_name="Church Center"
    )
    scc = models.ForeignKey(
        SCC,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='feast_collections',
        verbose_name="Small Christian Community"
    )
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    telephone = models.CharField(max_length=20)

    active_year = models.ForeignKey(
        ChurchYear,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='feast_collections'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Feast Collection"
        verbose_name_plural = "Feast Collections"
        ordering = ["-date", "name"]

    def save(self, *args, **kwargs):
        if not self.active_year:
            self.active_year = ChurchYear.objects.filter(is_active=True).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} - {self.collection_type} - {self.church_center.name} ({self.amount})"