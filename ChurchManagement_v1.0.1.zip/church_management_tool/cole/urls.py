from django.urls import path
from . import views 
from .views import check_updates_view, update_page_view

urlpatterns = [
    # Daily Tithe
    path('add-daily-tithe/', views.add_daily_tithe_view, name='add_daily_tithe'),
    path('view-daily-tithe/', views.view_daily_tithe_view, name='view_daily_tithe'),
    
    # Annual Tithe
    path('add-annual-tithe/', views.add_annual_tithe_view, name='add_annual_tithe'),
    path('view-annual-tithe/', views.view_annual_tithe_view, name='view_annual_tithe'),
    
    # Feast Collections
    path('add-christmas/', views.add_christmas_view, name='add_christmas'),
    path('add-easter/', views.add_easter_view, name='add_easter'),
    path('add-mother-mary/', views.add_mother_mary_view, name='add_mother_mary'),
    path('view-feasts/', views.view_feasts_view, name='view_feasts'),  # Add this
    
    # Church Centers
    path('town-church/', views.town_church_view, name='town_church'),
    path('nyabukara-church/', views.nyabukara_church_view, name='nyabukara_church'),
    path('kagote-church/', views.kagote_church_view, name='kagote_church'),
    path('kyakaigo-church/', views.kyakaigo_church_view, name='kyakaigo_church'),
    path('buzinda-church/', views.buzinda_church_view, name='buzinda_church'),
    path('api/get_sccs_by_church/', views.get_sccs_by_church, name='get_sccs_by_church'),

    #updting
    path('updates/', update_page_view, name='updates'),
    path('api/check-updates/', check_updates_view, name='check_updates_api'),
    
]