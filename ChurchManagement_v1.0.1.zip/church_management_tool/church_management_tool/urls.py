from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', lambda request: redirect('login')),  # Redirect root to login
    path('members/', include('members.urls')),
    path('cole/', include('cole.urls')),
    path('marraige/', include('marraige.urls')),
    # Add other app URLs here
]