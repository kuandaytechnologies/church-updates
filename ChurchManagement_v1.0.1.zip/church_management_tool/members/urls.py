from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # Home & Dashboard
    path('', views.home_view, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # Members
    path('members/', views.view_members, name='view_members'),
    path('members/add/', views.add_member, name='add_member'),
    path('members/<int:pk>/', views.member_detail, name='member_detail'),
    path('members/call/', views.call_members, name='call_members'),  # ADD THIS LINE
    path('members/<int:pk>/edit/', views.member_update, name='member_update'),
    path('members/<int:pk>/delete/', views.member_delete, name='member_delete'),

    path('api/sccs/<int:church_id>/', views.get_sccs_by_church, name='get_sccs_by_church'),
    
    
    
    # Baptisms
    path('baptisms/', views.view_baptism, name='view_baptism'),
    path('baptisms/add/', views.add_baptism, name='add_baptism'),
    path('baptisms/<int:pk>/', views.baptism_detail, name='baptism_detail'),
    path('baptisms/<int:pk>/edit/', views.baptism_update, name='baptism_update'),
    path('baptisms/<int:pk>/delete/', views.baptism_delete, name='baptism_delete'),
    
    # Church Years
    path('church-years/', views.church_year_list, name='church_year_list'),
    path('church-years/add/', views.church_year_create, name='church_year_create'),
    path('church-years/<int:pk>/edit/', views.church_year_update, name='church_year_update'),
    path('church-years/<int:pk>/delete/', views.church_year_delete, name='church_year_delete'),
    path('church-years/<int:pk>/set-active/', views.set_active_year, name='set_active_year'),

     # User Management
    path('users/add/', views.add_user, name='add_user'),  # ADD THIS LINE
    path('users/assign-role/', views.assign_role, name='assign_role'),  # ADD THIS LINE TOO

]