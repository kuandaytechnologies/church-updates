
from members.models import ChurchYear

def active_year(request):
    """
    Context processor to make active year available in all templates
    """
    try:
        active_year = ChurchYear.objects.filter(is_active=True).first()
        return {'active_year': active_year}
    except:
        return {'active_year': None}