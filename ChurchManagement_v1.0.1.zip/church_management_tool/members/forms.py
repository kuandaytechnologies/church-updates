
from django import forms
from .models import Member, Baptism, ChurchYear

from django import forms
from .models import Member, Baptism, ChurchYear, Church, SCC

class MemberForm(forms.ModelForm):
    class Meta:
        model = Member
        fields = [
            'title', 'name', 'date_of_birth', 'status',
            'lay_apostolate', 'baptised', 'catechism_level', 'education_level',
            'occupation', 'church_center', 'scc', 'phone'
        ]
        widgets = {
            'title': forms.Select(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter full name'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
            'lay_apostolate': forms.Select(attrs={'class': 'form-control'}),
            'baptised': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'catechism_level': forms.Select(attrs={'class': 'form-control'}),
            'education_level': forms.Select(attrs={'class': 'form-control'}),
            'occupation': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter occupation'}),
            'church_center': forms.Select(attrs={'class': 'form-control', 'id': 'id_church_center'}),
            'scc': forms.Select(attrs={'class': 'form-control', 'id': 'id_scc'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter phone number'}),
        }
        labels = {
            'title': 'Title',
            'name': 'Full Name',
            'date_of_birth': 'Date of Birth',
            'status': 'Marital/Religious Status',
            'lay_apostolate': 'Lay Apostolate',
            'baptised': 'Is Baptised?',
            'catechism_level': 'Catechism Level',
            'education_level': 'Education Level',
            'occupation': 'Occupation',
            'church_center': 'Church Center',
            'scc': 'Small Christian Community (SCC)',
            'phone': 'Phone Number',
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Set empty_label for church_center
        self.fields['church_center'].empty_label = "--Select Church--"
        self.fields['scc'].empty_label = "--Select SCC--"
        
        # CRITICAL FIX: Allow all active SCCs for validation
        self.fields['scc'].queryset = SCC.objects.filter(is_active=True)
        
        # If we have POST data with a church selected, filter SCCs by that church
        if 'church_center' in self.data:
            try:
                church_id = int(self.data.get('church_center'))
                self.fields['scc'].queryset = SCC.objects.filter(
                    church_id=church_id,
                    is_active=True
                )
            except (ValueError, TypeError):
                pass  # Invalid input, keep all SCCs
        # If editing existing member, filter by their church
        elif self.instance.pk and self.instance.church_center:
            self.fields['scc'].queryset = SCC.objects.filter(
                church=self.instance.church_center,
                is_active=True
            )



class BaptismForm(forms.ModelForm):
    """Form for creating and updating Baptism records"""
    
    class Meta:
        model = Baptism
        fields = [
            'name', 'christian_name', 'date_of_birth', 'residence',
            'father_name', 'father_contact', 'mother_name', 'mother_contact',
            'god_parent', 'status', 'baptism_fee', 'baptism_date', 'tithe', 'minister'
        ]
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name'}),
            'christian_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Christian Name'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'residence': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Residence'}),
            'father_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Father's Name"}),
            'father_contact': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Father's Contact"}),
            'mother_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Mother's Name"}),
            'mother_contact': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Mother's Contact"}),
            'god_parent': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Godparent's Name"}),
            'status': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Infant / Adult'}),
            'baptism_fee': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'placeholder': '0.00'}),
            'baptism_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'tithe': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01', 'placeholder': '0.00'}),
            'minister': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Minister Name'}),
        }
        labels = {
            'name': 'Full Name',
            'christian_name': 'Christian Name',
            'date_of_birth': 'Date of Birth',
            'father_contact': "Father's Contact",
            'mother_contact': "Mother's Contact",
            'god_parent': 'Godparent',
            'baptism_fee': 'Baptism Fee',
            'baptism_date': 'Baptism Date',
        }


class ChurchYearForm(forms.ModelForm):
    """Form for creating and updating ChurchYear records"""
    
    class Meta:
        model = ChurchYear
        fields = ['year', 'is_active']
        widgets = {
            'year': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'e.g., 2025'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
        labels = {
            'year': 'Church Year',
            'is_active': 'Set as Active Year',
        }

