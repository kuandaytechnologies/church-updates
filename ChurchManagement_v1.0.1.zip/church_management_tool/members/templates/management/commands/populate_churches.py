# management/commands/populate_churches.py
# Place this file in: members/management/commands/populate_churches.py

from django.core.management.base import BaseCommand
from members.models import Church, SCC


class Command(BaseCommand):
    help = 'Populate initial Church and SCC data'

    def handle(self, *args, **options):
        # Define churches to create
        churches_data = [
            {'name': 'Town Church', 'code': 'town_church'},
            {'name': 'Nyabukara Church', 'code': 'nyabukara_church'},
            {'name': 'Kagote Church', 'code': 'kagote_church'},
            {'name': 'Buzinda Church', 'code': 'buzinda_church'},
            {'name': 'Kyakaigo Church', 'code': 'kyakaigo_church'},
        ]
        
        # Create churches
        for church_data in churches_data:
            church, created = Church.objects.get_or_create(
                code=church_data['code'],
                defaults={
                    'name': church_data['name'],
                    'is_active': True
                }
            )
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Created church: {church.name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Church already exists: {church.name}')
                )
        
        # Optional: Create some sample SCCs for each church
        scc_samples = [
            'St. Joseph SCC',
            'St. Mary SCC',
            'St. Peter SCC',
            'St. Paul SCC',
            'St. John SCC',
        ]
        
        create_sample_sccs = input('Do you want to create sample SCCs? (y/n): ')
        
        if create_sample_sccs.lower() == 'y':
            for church in Church.objects.filter(is_active=True):
                for i, scc_name in enumerate(scc_samples[:3], 1):  # Create 3 SCCs per church
                    scc, created = SCC.objects.get_or_create(
                        name=f'{scc_name} - {i}',
                        church=church,
                        defaults={'is_active': True}
                    )
                    if created:
                        self.stdout.write(
                            self.style.SUCCESS(f'Created SCC: {scc.name} for {church.name}')
                        )
        
        self.stdout.write(self.style.SUCCESS('Successfully populated churches!'))
