

# Register your models here.
from django.contrib import admin

from .models import Member, Baptism, ChurchYear, Church, SCC



@admin.register(Member)
class MemberAdmin(admin.ModelAdmin):
    list_display = ("title", "name", "status", "lay_apostolate", "church_center", "phone", "created_at")
    search_fields = ("name", "phone", "scc")
    list_filter = ("status", "church_center", "lay_apostolate")



@admin.register(Baptism)
class BaptismAdmin(admin.ModelAdmin):
    list_display = ("christian_name", "name", "baptism_date", "minister", "baptism_fee", "tithe")
    search_fields = ("name", "christian_name", "father_name", "mother_name", "minister")
    list_filter = ("baptism_date", "minister")


@admin.register(Church)
class ChurchAdmin(admin.ModelAdmin):
    list_display = ['name', 'code', 'is_active']
    list_filter = ['is_active']
    search_fields = ['name', 'code']

@admin.register(SCC)
class SCCAdmin(admin.ModelAdmin):
    list_display = ['name', 'church', 'is_active']
    list_filter = ['church', 'is_active']
    search_fields = ['name']


