from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator
from .models import Member, Baptism, ChurchYear, UserRole, Church, SCC  # Add Church and SCC
from .forms import MemberForm, BaptismForm, ChurchYearForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model
from django.http import JsonResponse


# ==================== Member Views ====================
@login_required
def view_members(request):
    """Display list of all members with search and filter functionality"""
    members = Member.objects.all().order_by('-created_at')
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        members = members.filter(
            Q(name__icontains=search_query) |
            Q(phone__icontains=search_query) |
            Q(scc__name__icontains=search_query)  # Updated to use ForeignKey
        )
    
    # Filter by church center
    church_filter = request.GET.get('church', '')
    if church_filter:
        members = members.filter(church_center_id=church_filter)  # Updated to use ID
    
    # Filter by active year
    year_filter = request.GET.get('year', '')
    if year_filter:
        members = members.filter(active_year__year=year_filter)
    
    # Pagination
    paginator = Paginator(members, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'church_filter': church_filter,
        'year_filter': year_filter,
        'churches': Church.objects.filter(is_active=True),  # CHANGED: Use Church model
        'years': ChurchYear.objects.all().order_by('-year'),
    }
    return render(request, 'members/view_members.html', context)

@login_required
def member_detail(request, pk):
    """Display detailed information about a specific member"""
    member = get_object_or_404(Member, pk=pk)
    context = {'member': member}
    return render(request, 'members/member_detail.html', context)

@login_required
def add_member(request):
    """Create a new member"""
    if request.method == 'POST':
        form = MemberForm(request.POST)
        if form.is_valid():
            member = form.save()
            messages.success(request, f'Member {member.name} created successfully!')
            return redirect('member_detail', pk=member.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = MemberForm()
    
    context = {'form': form}
    return render(request, 'members/member_form.html', context)


@login_required
def member_update(request, pk):
    """Update an existing member"""
    member = get_object_or_404(Member, pk=pk)
    
    if request.method == 'POST':
        form = MemberForm(request.POST, instance=member)
        if form.is_valid():
            member = form.save()
            messages.success(request, f'Member {member.name} updated successfully!')
            return redirect('member_detail', pk=member.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = MemberForm(instance=member)
    
    context = {'form': form, 'member': member}
    return render(request, 'members/member_form.html', context)


@login_required
def member_delete(request, pk):
    """Delete a member"""
    member = get_object_or_404(Member, pk=pk)
    
    if request.method == 'POST':
        member_name = member.name
        member.delete()
        messages.success(request, f'Member {member_name} deleted successfully!')
        return redirect('view_members')
    
    context = {'member': member}
    return render(request, 'members/member_confirm_delete.html', context)


# ==================== Baptism Views ====================

@login_required
def view_baptism(request):
    """Display list of all baptisms with search functionality"""
    baptisms = Baptism.objects.all().order_by('-baptism_date')
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        baptisms = baptisms.filter(
            Q(name__icontains=search_query) |
            Q(christian_name__icontains=search_query) |
            Q(father_name__icontains=search_query) |
            Q(mother_name__icontains=search_query)
        )
    
    # Filter by year
    year_filter = request.GET.get('year', '')
    if year_filter:
        baptisms = baptisms.filter(active_year__year=year_filter)
    
    # Pagination
    paginator = Paginator(baptisms, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'year_filter': year_filter,
        'years': ChurchYear.objects.all().order_by('-year'),
    }
    return render(request, 'baptisms/view_baptism.html', context)


@login_required
def baptism_detail(request, pk):
    """Display detailed information about a specific baptism"""
    baptism = get_object_or_404(Baptism, pk=pk)
    context = {'baptism': baptism}
    return render(request, 'baptisms/baptism_detail.html', context)


@login_required
def add_baptism(request):
    """Create a new baptism record"""
    if request.method == 'POST':
        form = BaptismForm(request.POST)
        if form.is_valid():
            baptism = form.save()
            messages.success(request, f'Baptism record for {baptism.christian_name} created successfully!')
            return redirect('baptism_detail', pk=baptism.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = BaptismForm()
    
    context = {'form': form}
    return render(request, 'baptisms/baptism_form.html', context)


@login_required
def baptism_update(request, pk):
    """Update an existing baptism record"""
    baptism = get_object_or_404(Baptism, pk=pk)
    
    if request.method == 'POST':
        form = BaptismForm(request.POST, instance=baptism)
        if form.is_valid():
            baptism = form.save()
            messages.success(request, f'Baptism record for {baptism.christian_name} updated successfully!')
            return redirect('baptism_detail', pk=baptism.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = BaptismForm(instance=baptism)
    
    context = {'form': form, 'baptism': baptism}
    return render(request, 'baptisms/baptism_form.html', context)


@login_required
def baptism_delete(request, pk):
    """Delete a baptism record"""
    baptism = get_object_or_404(Baptism, pk=pk)
    
    if request.method == 'POST':
        baptism_name = baptism.christian_name
        baptism.delete()
        messages.success(request, f'Baptism record for {baptism_name} deleted successfully!')
        return redirect('view_baptism')
    
    context = {'baptism': baptism}
    return render(request, 'baptisms/baptism_confirm_delete.html', context)


# ==================== Church Year Views ====================
@login_required
def church_year_list(request):
    """Display list of all church years"""
    years = ChurchYear.objects.all().order_by('-year')
    context = {'years': years}
    return render(request, 'church_years/year_list.html', context)


@login_required
def church_year_create(request):
    """Create a new church year"""
    if request.method == 'POST':
        year_number = request.POST.get('year')
        is_active = request.POST.get('is_active') == 'on'
        
        try:
            year = ChurchYear.objects.create(
                year=year_number,
                is_active=is_active
            )
            messages.success(request, f'Church year {year.year} created successfully!')
        except Exception as e:
            messages.error(request, f'Error creating year: {str(e)}')
    
    return redirect('church_year_list')


@login_required
def church_year_update(request, pk):
    """Update an existing church year"""
    year = get_object_or_404(ChurchYear, pk=pk)
    
    if request.method == 'POST':
        try:
            year.year = request.POST.get('year')
            year.is_active = request.POST.get('is_active') == 'on'
            year.save()
            messages.success(request, f'Church year {year.year} updated successfully!')
        except Exception as e:
            messages.error(request, f'Error updating year: {str(e)}')
    
    return redirect('church_year_list')


@login_required
def church_year_delete(request, pk):
    """Delete a church year"""
    year = get_object_or_404(ChurchYear, pk=pk)
    
    if request.method == 'POST':
        year_number = year.year
        try:
            year.delete()
            messages.success(request, f'Church year {year_number} deleted successfully!')
        except Exception as e:
            messages.error(request, f'Error deleting year: {str(e)}')
    
    return redirect('church_year_list')


@login_required
def set_active_year(request, pk):
    """Set a specific year as the active church year"""
    if request.method == 'POST':
        year = get_object_or_404(ChurchYear, pk=pk)
        year.is_active = True
        year.save()
        messages.success(request, f'Church year {year.year} is now active!')
    
    return redirect('church_year_list')

# ==================== Home/Dashboard Views ====================

def home_view(request):
    """Home page view - redirects to dashboard if logged in"""
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'home.html')


@login_required
def dashboard(request):
    """Display dashboard with statistics"""
    active_year = ChurchYear.objects.filter(is_active=True).first()
    
    context = {
        'total_members': Member.objects.count(),
        'total_baptisms': Baptism.objects.count(),
        'active_year': active_year,
        'members_this_year': Member.objects.filter(active_year=active_year).count() if active_year else 0,
        'baptisms_this_year': Baptism.objects.filter(active_year=active_year).count() if active_year else 0,
        'recent_members': Member.objects.all().order_by('-created_at')[:5],
        'recent_baptisms': Baptism.objects.all().order_by('-baptism_date')[:5],
    }
    return render(request, 'members/dashboard.html', context)


def login_view(request):
    # Redirect if already logged in
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
            next_url = request.GET.get('next', 'home')
            return redirect(next_url)
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'members/login.html')


def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out successfully.')
    return redirect('login')


@login_required
def call_members(request):
    """Display members with phone numbers for calling"""
    members = Member.objects.filter(phone__isnull=False).exclude(phone='').order_by('name')
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        members = members.filter(
            Q(name__icontains=search_query) |
            Q(phone__icontains=search_query) |
            Q(scc__icontains=search_query)
        )
    
    # Filter by church center
    church_filter = request.GET.get('church', '')
    if church_filter:
        members = members.filter(church_center=church_filter)
    
    context = {
        'members': members,
        'search_query': search_query,
        'church_filter': church_filter,
        'church_choices': Member.CHURCH_CHOICES,
    }
    return render(request, 'members/call_members.html', context)



# ==================== User Management Views ====================



User = get_user_model()

@login_required
def add_user(request):
    """Create a new user account"""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, f'User {user.username} created successfully!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = UserCreationForm()
    
    context = {'form': form}
    return render(request, 'users/user_form.html', context)


@login_required
def assign_role(request):
    """Assign roles to users"""
    users = User.objects.all()
    roles = UserRole.objects.all()
    
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        role_id = request.POST.get('role_id')
        
        # Add your role assignment logic here
        messages.success(request, 'Role assigned successfully!')
        return redirect('assign_role')
    
    context = {
        'users': users,
        'roles': roles,
    }
    return render(request, 'users/assign_role.html', context)



def get_sccs_by_church(request, church_id):
    """API endpoint to get SCCs for a specific church"""
    sccs = SCC.objects.filter(church_id=church_id, is_active=True).values('id', 'name')
    return JsonResponse(list(sccs), safe=False)


