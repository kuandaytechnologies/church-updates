# Create your models here.
from django.db import models
from django.contrib.auth.models import AbstractUser

class Member(models.Model):
    TITLES = [
        ("Mr", "Mr."),
        ("Miss", "Miss."),
        ("Mrs", "Mrs."),
        ("Hon", "Hon."),
        ("Rev.Bro", "Rev. Bro."),
        ("Rev.Sr", "Rev. Sr."),
        ("Rev.Fr", "Rev. Fr."),
    ]

    STATUS_CHOICES = [
        ("Single", "Single"),
        ("Married", "Married"),
        ("Religious", "Religious"),
        ("Ordained Minister", "Ordained Minister"),
    ]

    LAY_APOSTOLATE_CHOICES = [
        ("abakaiso ba yesu", "Abakaiso ba Yesu"),
        ("Catholic Charismatic Renewal", "Catholic Charismatic Renewal"),
        ("Divine Mercy", "Divine Mercy"),
        ("Legion of Mary", "Legion of Mary"),
        ("Abazaveri", "Abazaveri"),
        ("Uganda Catholic Women", "Uganda Catholic Women"),
        ("Holy Childhood", "Holy Childhood"),
        ("Omutima gwa Yesu", "Omutima gwa Yesu"),
        ("Purgatory", "Purgatory"),
        ("Pioneer", "Pioneer"),
        ("Jesus Youth", "Jesus Youth"),
        ("Youth Apostolate", "Youth Apostolate"),
    ]

    CATECHISM_CHOICES = [
        ("First Holy Communion", "First Holy Communion"),
        ("Confirmed", "Confirmed"),
        ("Holy Matrimony & Confirmed", "Holy Matrimony & Confirmed"),
        ("Holy Matrimony & not-Confirmed", "Holy Matrimony & not-Confirmed"),
        ("Ordained Minister", "Ordained Minister"),
        ("Religious", "Religious"),
        ("Not yet", "Not yet"),
    ]

    EDUCATION_CHOICES = [
        ("Nursery", "Nursery"),
        ("Primary", "Primary"),
        ("Secondary", "Secondary"),
        ("Diploma", "Diploma"),
        ("Degree", "Degree"),
        ("Masters", "Masters"),
        ("Post graduate", "Post graduate"),
        ("PhD", "PhD"),
    ]

    # Step 1 fields
    title = models.CharField(max_length=20, choices=TITLES)
    name = models.CharField(max_length=200)
    date_of_birth = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES)

    # Step 2 fields
    lay_apostolate = models.CharField(max_length=100, choices=LAY_APOSTOLATE_CHOICES, blank=True, null=True)
    baptised = models.BooleanField(default=False)
    catechism_level = models.CharField(max_length=50, choices=CATECHISM_CHOICES, blank=True, null=True)
    education_level = models.CharField(max_length=50, choices=EDUCATION_CHOICES, blank=True, null=True)

    # Step 3 fields
    occupation = models.CharField(max_length=200, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    
    # Church relationships - USE ONLY THESE (ForeignKey, not CharField)
    church_center = models.ForeignKey(
        'Church',  # Use quotes since Church is defined below
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='members'
    )
    scc = models.ForeignKey(
        'SCC',  # Use quotes since SCC is defined below
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='members'
    )

    # Church year tracking
    active_year = models.ForeignKey(
        "ChurchYear",
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.active_year:
            self.active_year = ChurchYear.objects.filter(is_active=True).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.title} {self.name}"


# Church dynamic selection - DEFINE THESE BEFORE Member MODEL
class Church(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        verbose_name_plural = "Churches"
        ordering = ['name']
    
    def __str__(self):
        return self.name


class SCC(models.Model):
    name = models.CharField(max_length=200)
    church = models.ForeignKey(Church, on_delete=models.CASCADE, related_name='sccs')
    is_active = models.BooleanField(default=True)
    
    class Meta:
        verbose_name = "Small Christian Community"
        verbose_name_plural = "Small Christian Communities"
        ordering = ['church', 'name']
    
    def __str__(self):
        return f"{self.name} - {self.church.name}"
    

    #baptism

class Baptism(models.Model):
    # Candidate info
    name = models.CharField(max_length=200)             # Full Name
    christian_name = models.CharField(max_length=200)   # Christian Name
    date_of_birth = models.DateField()                  # Date of Birth
    residence = models.CharField(max_length=255, blank=True, null=True)

    # Parents info
    father_name = models.CharField(max_length=200)
    father_contact = models.CharField(max_length=20, blank=True, null=True)
    mother_name = models.CharField(max_length=200)
    mother_contact = models.CharField(max_length=20, blank=True, null=True)

    # Godparent
    god_parent = models.CharField(max_length=200, blank=True, null=True)

    # Sacrament info
    status = models.CharField(max_length=100, blank=True, null=True)  # e.g., Infant / Adult
    baptism_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    baptism_date = models.DateField()

    tithe = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    minister = models.CharField(max_length=200)

    # Church year tracking
    active_year = models.ForeignKey(
        "ChurchYear",
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.active_year:
            self.active_year = ChurchYear.objects.filter(is_active=True).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Baptism: {self.christian_name} ({self.name})"


# User roles
class UserRole(models.Model):
    ROLE_CHOICES = [
        ("manager", "Manager"),
        ("secretary", "Secretary"),
        ("viewer", "Viewer"),
    ]
    name = models.CharField(max_length=50, choices=ROLE_CHOICES, unique=True)

    def __str__(self):
        return self.get_name_display()


# Custom User

class CustomUser(AbstractUser):
    # Add related_name to avoid clashes
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='custom_user_set',  # Changed from default 'user_set'
        blank=True,
        help_text='The groups this user belongs to.',
        verbose_name='groups',
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='custom_user_set',  # Changed from default 'user_set'
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions',
    )

# Church Year
class ChurchYear(models.Model):
    year = models.PositiveIntegerField(unique=True)
    is_active = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        status = "Active" if self.is_active else "Inactive"
        return f"{self.year} - {status}"

    def save(self, *args, **kwargs):
        # Ensure only one year is active at a time
        if self.is_active:
            ChurchYear.objects.filter(is_active=True).update(is_active=False)
        super().save(*args, **kwargs)


