
# urls.py - Add these URL patterns to your marriage app URLs

from django.urls import path
from . import views

urlpatterns = [
    # View marriage records
    path('marriage/', views.view_marriage_view, name='view_marriage'),
    
    # Groom URLs
    path('marriage/groom/add/', views.add_groom_view, name='add_groom'),
    path('marriage/groom/edit/<int:groom_id>/', views.edit_groom_view, name='edit_groom'),
    path('marriage/groom/delete/<int:groom_id>/', views.delete_groom_view, name='delete_groom'),
    
    # Bride URLs
    path('marriage/bride/add/', views.add_bride_view, name='add_bride'),
    path('marriage/bride/edit/<int:bride_id>/', views.edit_bride_view, name='edit_bride'),
    path('marriage/bride/delete/<int:bride_id>/', views.delete_bride_view, name='delete_bride'),
    
    # Assign couple
    path('marriage/assign-couple/', views.assign_couple_view, name='assign_couple'),
]