from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Groom, Bride, ChurchYear

@login_required
def add_groom_view(request):
    """Add groom"""
    if request.method == 'POST':
        try:
            Groom.objects.create(
                # Basic info
                name=request.POST.get('name'),
                residence=request.POST.get('residence'),
                district=request.POST.get('district'),
                date_of_birth=request.POST.get('date_of_birth'),
                occupation=request.POST.get('occupation'),
                couple_condition=request.POST.get('couple_condition'),
                
                # Parents
                mother_name=request.POST.get('mother_name'),
                father_name=request.POST.get('father_name'),
                father_occupation=request.POST.get('father_occupation'),
                
                # Sacramental info
                place_of_baptism=request.POST.get('place_of_baptism'),
                confirmation_place=request.POST.get('confirmation_place'),
                
                # IDs & contact
                nin=request.POST.get('nin'),
                telephone=request.POST.get('telephone'),
                
                # Clan info
                mother_clan=request.POST.get('mother_clan'),
                clan=request.POST.get('clan'),
                
                # Marriage preparation
                bride_wealth_paid=request.POST.get('bride_wealth_paid') == 'on',
                has_house=request.POST.get('has_house') == 'on',
                parents_in_favour=request.POST.get('parents_in_favour') == 'on',
                monogamy_acceptance=request.POST.get('monogamy_acceptance') == 'on',
                
                # Witness & Registration
                witness_name=request.POST.get('witness_name'),
                registration_date=request.POST.get('registration_date'),
                banns_date=request.POST.get('banns_date'),
                banns_parish=request.POST.get('banns_parish'),
                
                # Fees
                marriage_fee=request.POST.get('marriage_fee') or 0,
                instruction_fee=request.POST.get('instruction_fee') or 0,
                government_fee=request.POST.get('government_fee') or 0,
                late_fee=request.POST.get('late_fee') or 0,
                
                # Signature
                signature=request.POST.get('signature'),
                parish_priest_stamp=request.POST.get('parish_priest_stamp'),
            )
            messages.success(request, 'Groom added successfully!')
            return redirect('view_marriage')
        except Exception as e:
            messages.error(request, f'Error adding groom: {str(e)}')
    
    return render(request, 'marraige/add_groom.html', {
        'page_title': 'Add Groom'
    })


@login_required
def edit_groom_view(request, groom_id):
    """Edit existing groom record"""
    groom = get_object_or_404(Groom, id=groom_id)
    
    if request.method == 'POST':
        try:
            # Update basic info
            groom.name = request.POST.get('name')
            groom.residence = request.POST.get('residence')
            groom.district = request.POST.get('district')
            groom.date_of_birth = request.POST.get('date_of_birth')
            groom.occupation = request.POST.get('occupation')
            groom.couple_condition = request.POST.get('couple_condition')
            
            # Update parents
            groom.mother_name = request.POST.get('mother_name')
            groom.father_name = request.POST.get('father_name')
            groom.father_occupation = request.POST.get('father_occupation')
            
            # Update sacramental info
            groom.place_of_baptism = request.POST.get('place_of_baptism')
            groom.confirmation_place = request.POST.get('confirmation_place')
            
            # Update IDs & contact
            groom.nin = request.POST.get('nin')
            groom.telephone = request.POST.get('telephone')
            
            # Update clan info
            groom.mother_clan = request.POST.get('mother_clan')
            groom.clan = request.POST.get('clan')
            
            # Update marriage preparation
            groom.bride_wealth_paid = request.POST.get('bride_wealth_paid') == 'on'
            groom.has_house = request.POST.get('has_house') == 'on'
            groom.parents_in_favour = request.POST.get('parents_in_favour') == 'on'
            groom.monogamy_acceptance = request.POST.get('monogamy_acceptance') == 'on'
            
            # Update witness & registration
            groom.witness_name = request.POST.get('witness_name')
            groom.registration_date = request.POST.get('registration_date')
            groom.banns_date = request.POST.get('banns_date')
            groom.banns_parish = request.POST.get('banns_parish')
            
            # Update fees
            groom.marriage_fee = request.POST.get('marriage_fee') or 0
            groom.instruction_fee = request.POST.get('instruction_fee') or 0
            groom.government_fee = request.POST.get('government_fee') or 0
            groom.late_fee = request.POST.get('late_fee') or 0
            
            # Update signature
            groom.signature = request.POST.get('signature')
            groom.parish_priest_stamp = request.POST.get('parish_priest_stamp')
            
            groom.save()
            messages.success(request, 'Groom record updated successfully!')
            return redirect('view_marriage')
        except Exception as e:
            messages.error(request, f'Error updating groom: {str(e)}')
    
    return render(request, 'marraige/edit_groom.html', {
        'page_title': 'Edit Groom',
        'groom': groom
    })


@login_required
def delete_groom_view(request, groom_id):
    """Delete groom record"""
    if request.method == 'POST':
        try:
            groom = get_object_or_404(Groom, id=groom_id)
            groom.delete()
            messages.success(request, 'Groom record deleted successfully!')
        except Exception as e:
            messages.error(request, f'Error deleting groom: {str(e)}')
    
    return redirect('view_marriage')


@login_required
def add_bride_view(request):
    """Add bride"""
    if request.method == 'POST':
        try:
            Bride.objects.create(
                # Basic info
                name=request.POST.get('name'),
                residence=request.POST.get('residence'),
                district=request.POST.get('district'),
                date_of_birth=request.POST.get('date_of_birth'),
                occupation=request.POST.get('occupation'),
                couple_condition=request.POST.get('couple_condition'),
                
                # Parents
                mother_name=request.POST.get('mother_name'),
                father_name=request.POST.get('father_name'),
                father_occupation=request.POST.get('father_occupation'),
                
                # Sacramental info
                place_of_baptism=request.POST.get('place_of_baptism'),
                confirmation_place=request.POST.get('confirmation_place'),
                
                # IDs & contact
                nin=request.POST.get('nin'),
                telephone=request.POST.get('telephone'),
                
                # Clan info
                mother_clan=request.POST.get('mother_clan'),
                clan=request.POST.get('clan'),
                
                # Marriage preparation
                dowry_received=request.POST.get('dowry_received') == 'on',
                parents_in_favour=request.POST.get('parents_in_favour') == 'on',
                monogamy_acceptance=request.POST.get('monogamy_acceptance') == 'on',
                
                # Witness & Registration
                witness_name=request.POST.get('witness_name'),
                registration_date=request.POST.get('registration_date'),
                banns_date=request.POST.get('banns_date'),
                banns_parish=request.POST.get('banns_parish'),
                
                # Fees
                marriage_fee=request.POST.get('marriage_fee') or 0,
                instruction_fee=request.POST.get('instruction_fee') or 0,
                government_fee=request.POST.get('government_fee') or 0,
                late_fee=request.POST.get('late_fee') or 0,
                
                # Signature
                signature=request.POST.get('signature'),
                parish_priest_stamp=request.POST.get('parish_priest_stamp'),
            )
            messages.success(request, 'Bride added successfully!')
            return redirect('view_marriage')
        except Exception as e:
            messages.error(request, f'Error adding bride: {str(e)}')
    
    return render(request, 'marraige/add_bride.html', {
        'page_title': 'Add Bride'
    })


@login_required
def edit_bride_view(request, bride_id):
    """Edit existing bride record"""
    bride = get_object_or_404(Bride, id=bride_id)
    
    if request.method == 'POST':
        try:
            # Update basic info
            bride.name = request.POST.get('name')
            bride.residence = request.POST.get('residence')
            bride.district = request.POST.get('district')
            bride.date_of_birth = request.POST.get('date_of_birth')
            bride.occupation = request.POST.get('occupation')
            bride.couple_condition = request.POST.get('couple_condition')
            
            # Update parents
            bride.mother_name = request.POST.get('mother_name')
            bride.father_name = request.POST.get('father_name')
            bride.father_occupation = request.POST.get('father_occupation')
            
            # Update sacramental info
            bride.place_of_baptism = request.POST.get('place_of_baptism')
            bride.confirmation_place = request.POST.get('confirmation_place')
            
            # Update IDs & contact
            bride.nin = request.POST.get('nin')
            bride.telephone = request.POST.get('telephone')
            
            # Update clan info
            bride.mother_clan = request.POST.get('mother_clan')
            bride.clan = request.POST.get('clan')
            
            # Update marriage preparation
            bride.dowry_received = request.POST.get('dowry_received') == 'on'
            bride.parents_in_favour = request.POST.get('parents_in_favour') == 'on'
            bride.monogamy_acceptance = request.POST.get('monogamy_acceptance') == 'on'
            
            # Update witness & registration
            bride.witness_name = request.POST.get('witness_name')
            bride.registration_date = request.POST.get('registration_date')
            bride.banns_date = request.POST.get('banns_date')
            bride.banns_parish = request.POST.get('banns_parish')
            
            # Update fees
            bride.marriage_fee = request.POST.get('marriage_fee') or 0
            bride.instruction_fee = request.POST.get('instruction_fee') or 0
            bride.government_fee = request.POST.get('government_fee') or 0
            bride.late_fee = request.POST.get('late_fee') or 0
            
            # Update signature
            bride.signature = request.POST.get('signature')
            bride.parish_priest_stamp = request.POST.get('parish_priest_stamp')
            
            bride.save()
            messages.success(request, 'Bride record updated successfully!')
            return redirect('view_marriage')
        except Exception as e:
            messages.error(request, f'Error updating bride: {str(e)}')
    
    return render(request, 'marraige/edit_bride.html', {
        'page_title': 'Edit Bride',
        'bride': bride
    })


@login_required
def delete_bride_view(request, bride_id):
    """Delete bride record"""
    if request.method == 'POST':
        try:
            bride = get_object_or_404(Bride, id=bride_id)
            bride.delete()
            messages.success(request, 'Bride record deleted successfully!')
        except Exception as e:
            messages.error(request, f'Error deleting bride: {str(e)}')
    
    return redirect('view_marriage')


@login_required
def view_marriage_view(request):
    """View marriage records"""
    active_year = ChurchYear.objects.filter(is_active=True).first()
    
    if active_year:
        grooms = Groom.objects.filter(active_year=active_year)
        brides = Bride.objects.filter(active_year=active_year)
    else:
        grooms = Groom.objects.all()
        brides = Bride.objects.all()
    
    return render(request, 'marraige/view_marriage.html', {
        'page_title': 'View Marriage Records',
        'grooms': grooms,
        'brides': brides,
    })


@login_required
def assign_couple_view(request):
    """Assign groom to bride"""
    if request.method == 'POST':
        groom_id = request.POST.get('groom_id')
        bride_id = request.POST.get('bride_id')
        
        try:
            groom = get_object_or_404(Groom, id=groom_id)
            bride = get_object_or_404(Bride, id=bride_id)
            
            # Here you would create a Marriage record if you have one
            # For now, we'll just show a success message
            messages.success(request, f'Successfully assigned {groom.name} to {bride.name}!')
            return redirect('assign_couple')
        except Exception as e:
            messages.error(request, f'Error assigning couple: {str(e)}')
    
    grooms = Groom.objects.all()
    brides = Bride.objects.all()
    
    return render(request, 'marraige/assign_couple.html', {
        'page_title': 'Assign Groom to Bride',
        'grooms': grooms,
        'brides': brides,
    })