from django.contrib import admin
from .models import Groom, Bride


@admin.register(Groom)
class GroomAdmin(admin.ModelAdmin):
    list_display = (
        "name", "district", "date_of_birth", "occupation",
        "telephone", "nin", "registration_date"
    )
    search_fields = ("name", "nin", "district", "telephone")
    list_filter = ("district", "registration_date", "monogamy_acceptance", "parents_in_favour")
    ordering = ("name",)


@admin.register(Bride)
class BrideAdmin(admin.ModelAdmin):
    list_display = (
        "name", "district", "date_of_birth", "occupation",
        "telephone", "nin", "registration_date"
    )
    search_fields = ("name", "nin", "district", "telephone")
    list_filter = ("district", "registration_date", "monogamy_acceptance", "parents_in_favour")
    ordering = ("name",)    
