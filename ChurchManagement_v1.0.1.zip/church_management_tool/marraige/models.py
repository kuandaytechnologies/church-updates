

from django.db import models
from members.models import ChurchYear

class Groom(models.Model):
    # Basic info
    name = models.CharField(max_length=200)
    residence = models.CharField(max_length=200)
    district = models.CharField(max_length=100)
    date_of_birth = models.DateField()

    occupation = models.CharField(max_length=150, blank=True, null=True)
    couple_condition = models.CharField(max_length=255, blank=True, null=True)  # condition at time of marriage

    # Parents
    mother_name = models.CharField(max_length=200)
    father_name = models.CharField(max_length=200)
    father_occupation = models.CharField(max_length=150, blank=True, null=True)

    # Sacramental info
    place_of_baptism = models.CharField(max_length=200, blank=True, null=True)
    confirmation_place = models.CharField(max_length=200, blank=True, null=True)

    # IDs & contact
    nin = models.CharField(max_length=20, unique=True)
    telephone = models.CharField(max_length=20, blank=True, null=True)

    # Clan info
    mother_clan = models.CharField(max_length=100, blank=True, null=True)
    clan = models.CharField(max_length=100, blank=True, null=True)

    # Marriage preparation info
    bride_wealth_paid = models.BooleanField(default=False)
    has_house = models.BooleanField(default=False)
    parents_in_favour = models.BooleanField(default=True)
    monogamy_acceptance = models.BooleanField(default=True)

    # Witness & Registration
    witness_name = models.CharField(max_length=200, blank=True, null=True)
    registration_date = models.DateField()
    banns_date = models.CharField(max_length=100, blank=True, null=True)   # can be stored as text or Date
    banns_parish = models.CharField(max_length=150, blank=True, null=True)

    # Fees
    marriage_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    instruction_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    government_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    late_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    # Signature
    signature = models.CharField(max_length=200, blank=True, null=True)
    parish_priest_stamp = models.CharField(max_length=200, blank=True, null=True)

    active_year = models.ForeignKey(
       "members.ChurchYear",
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.active_year:
            self.active_year = ChurchYear.objects.filter(is_active=True).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Groom: {self.name} ({self.nin})"




class Bride(models.Model):
    # Basic info
    name = models.CharField(max_length=200)
    residence = models.CharField(max_length=200)
    district = models.CharField(max_length=100)
    date_of_birth = models.DateField()

    occupation = models.CharField(max_length=150, blank=True, null=True)
    couple_condition = models.CharField(max_length=255, blank=True, null=True)  # condition at time of marriage

    # Parents
    mother_name = models.CharField(max_length=200)
    father_name = models.CharField(max_length=200)
    father_occupation = models.CharField(max_length=150, blank=True, null=True)

    # Sacramental info
    place_of_baptism = models.CharField(max_length=200, blank=True, null=True)
    confirmation_place = models.CharField(max_length=200, blank=True, null=True)

    # IDs & contact
    nin = models.CharField(max_length=20, unique=True)
    telephone = models.CharField(max_length=20, blank=True, null=True)

    # Clan info
    mother_clan = models.CharField(max_length=100, blank=True, null=True)
    clan = models.CharField(max_length=100, blank=True, null=True)

    # Marriage preparation info
    dowry_received = models.BooleanField(default=False)  # for bride's side
    parents_in_favour = models.BooleanField(default=True)
    monogamy_acceptance = models.BooleanField(default=True)

    # Witness & Registration
    witness_name = models.CharField(max_length=200, blank=True, null=True)
    registration_date = models.DateField()
    banns_date = models.CharField(max_length=100, blank=True, null=True)   # can be stored as text or Date
    banns_parish = models.CharField(max_length=150, blank=True, null=True)

    # Fees
    marriage_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    instruction_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    government_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    late_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    # Signature
    signature = models.CharField(max_length=200, blank=True, null=True)
    parish_priest_stamp = models.CharField(max_length=200, blank=True, null=True)

    active_year = models.ForeignKey(
       "members.ChurchYear",
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.active_year:
            self.active_year = ChurchYear.objects.filter(is_active=True).first()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Bride: {self.name} ({self.nin})"