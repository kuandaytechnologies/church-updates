# check_update.py
import urllib.request
import json
import sys
import os

# Your update server URL (use GitHub raw URL)
UPDATE_SERVER = "https://raw.githubusercontent.com/YOUR_USERNAME/church-updates/main/version.json"

def get_current_version():
    """Read current version from file"""
    try:
        with open('version.txt', 'r') as f:
            return f.read().strip()
    except Exception as e:
        print(f"Error reading version: {e}")
        return "1.0.0"

def check_for_update():
    """Check if update is available"""
    current = get_current_version()
    
    print(f"Current version: {current}")
    print("Checking for updates...")
    
    try:
        # Set timeout and user agent
        req = urllib.request.Request(UPDATE_SERVER)
        req.add_header('User-Agent', 'ChurchManagement/1.0')
        
        response = urllib.request.urlopen(req, timeout=10)
        data = json.loads(response.read().decode('utf-8'))
        
        latest = data['version']
        download_url = data['download_url']
        changes = data.get('changes', 'Bug fixes and improvements')
        
        print(f"Latest version: {latest}")
        
        # Simple version comparison
        if latest != current and latest > current:
            print("\n" + "="*60)
            print("          UPDATE AVAILABLE!")
            print("="*60)
            print(f"\nCurrent Version: {current}")
            print(f"New Version: {latest}")
            print(f"\nWhat's New:")
            print(changes)
            print(f"\nDownload URL:")
            print(download_url)
            print("\n" + "="*60)
            return {
                'available': True,
                'current': current,
                'latest': latest,
                'download_url': download_url,
                'changes': changes
            }
        else:
            print("\nYou are running the latest version!")
            return {'available': False, 'current': current}
    
    except urllib.error.URLError as e:
        print(f"\nError: Could not connect to update server.")
        print(f"Please check your internet connection.")
        print(f"Details: {e}")
        return {'error': str(e), 'current': current}
    
    except Exception as e:
        print(f"\nError checking for updates: {e}")
        return {'error': str(e), 'current': current}

if __name__ == '__main__':
    result = check_for_update()
    
    # Exit code for batch file
    if result.get('available'):
        sys.exit(1)  # Update available
    else:
        sys.exit(0)  # No update or error